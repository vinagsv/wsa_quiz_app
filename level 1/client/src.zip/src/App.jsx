import React, { useState } from "react";
import WelcomeScreen from "./components/WelcomeScreen";
import QuestionScreen from "./components/QuestionScreen";

export default function App() {
  const [viewScreen, setViewScreen] = useState("welcome");

  const showQuestionScreen = () => {
    setViewScreen("question");
  };
  return (
    <div>
      {viewScreen === "welcome" ? (
        <WelcomeScreen showQuestionScreen={showQuestionScreen} />
      ) : (
        <QuestionScreen />
      )}
    </div>
  );
}
